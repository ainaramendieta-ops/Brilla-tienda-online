const productos = [
  {id:1,nombre:"Collar Estrella",categoria:"Bijouterie",precio:4500,emoji:"⭐"},
  {id:2,nombre:"Bolso Mini",categoria:"Bolsos",precio:12500,emoji:"👜"},
  {id:3,nombre:"Pulsera Pink",categoria:"Bijouterie",precio:3800,emoji:"💗"},
  {id:4,nombre:"Lentes de sol",categoria:"Accesorios",precio:8900,emoji:"🕶️"},
  {id:5,nombre:"Llavero Corazón",categoria:"Accesorios",precio:2500,emoji:"🩷"},
  {id:6,nombre:"Cartera Urbana",categoria:"Bolsos",precio:15900,emoji:"👝"},
  {id:7,nombre:"Aros Brillantes",categoria:"Bijouterie",precio:5200,emoji:"✨"},
  {id:8,nombre:"Vincha Rosa",categoria:"Accesorios",precio:3100,emoji:"🎀"}
];
let carrito = [];
let categoriaActual = "Todos";
let favoritos = [];

const lista = document.getElementById("listaProductos");
const formatoPrecio = n => "$" + n.toLocaleString("es-AR");

function mostrarProductos() {
  const busqueda = document.getElementById("buscador").value.toLowerCase();
  const filtrados = productos.filter(p =>
    (categoriaActual === "Todos" || p.categoria === categoriaActual) &&
    p.nombre.toLowerCase().includes(busqueda)
  );
  lista.innerHTML = filtrados.length ? filtrados.map(p => `
    <article class="producto">
      <div class="imagen-producto">${p.emoji}</div>
      <div class="info-producto">
        <span class="categoria">${p.categoria}</span>
        <h3>${p.nombre}</h3>
        <div class="precio">${formatoPrecio(p.precio)}</div>
        <div class="acciones">
          <button class="boton agregar" onclick="agregarAlCarrito(${p.id})">Agregar</button>
          <button class="boton favorito" aria-label="Agregar a favoritos" onclick="alternarFavorito(${p.id})">${favoritos.includes(p.id) ? "♥" : "♡"}</button>
        </div>
      </div>
    </article>`).join("") : '<p>No se encontraron productos.</p>';
}
function agregarAlCarrito(id) {
  const item = carrito.find(p => p.id === id);
  if (item) item.cantidad++;
  else carrito.push({...productos.find(p => p.id === id), cantidad:1});
  document.getElementById("mensaje").textContent = "¡Producto agregado al carrito!";
  mostrarCarrito();
}
function cambiarCantidad(id, cambio) {
  const item = carrito.find(p => p.id === id);
  if (!item) return;
  item.cantidad += cambio;
  if (item.cantidad <= 0) carrito = carrito.filter(p => p.id !== id);
  mostrarCarrito();
}
function eliminarProducto(id) {
  carrito = carrito.filter(p => p.id !== id);
  document.getElementById("mensaje").textContent = "Producto eliminado del carrito.";
  mostrarCarrito();
}
function mostrarCarrito() {
  const contenido = document.getElementById("contenidoCarrito");
  contenido.innerHTML = carrito.length ? carrito.map(p => `
    <div class="item-carrito">
      <div><strong>${p.emoji} ${p.nombre}</strong><p>${formatoPrecio(p.precio)} cada uno</p></div>
      <div class="cantidad">
        <button onclick="cambiarCantidad(${p.id},-1)" aria-label="Restar">−</button>
        <span>${p.cantidad}</span>
        <button onclick="cambiarCantidad(${p.id},1)" aria-label="Sumar">+</button>
        <button class="eliminar" onclick="eliminarProducto(${p.id})">Eliminar</button>
      </div>
    </div>`).join("") : '<p class="vacio">Todavía no agregaste productos.</p>';
  const total = carrito.reduce((s,p) => s + p.precio*p.cantidad, 0);
  document.getElementById("total").textContent = formatoPrecio(total);
  document.getElementById("contador").textContent = carrito.reduce((s,p) => s+p.cantidad,0);
}
function alternarFavorito(id) {
  favoritos = favoritos.includes(id) ? favoritos.filter(x => x !== id) : [...favoritos,id];
  mostrarProductos();
}
document.getElementById("buscador").addEventListener("input", mostrarProductos);
document.querySelectorAll(".filtro").forEach(btn => btn.addEventListener("click", () => {
  categoriaActual = btn.dataset.categoria;
  document.querySelectorAll(".filtro").forEach(b => b.classList.toggle("activo", b === btn));
  mostrarProductos();
}));
document.getElementById("modoBtn").addEventListener("click", () => {
  document.body.classList.toggle("oscuro");
  document.getElementById("modoBtn").textContent = document.body.classList.contains("oscuro") ? "☀️" : "🌙";
});
document.getElementById("comprarBtn").addEventListener("click", () => {
  document.getElementById("mensaje").textContent = carrito.length
    ? "¡Gracias por tu compra! Este es un ejemplo de compra simulada."
    : "Primero agregá algún producto al carrito.";
});
mostrarProductos();
mostrarCarrito();
