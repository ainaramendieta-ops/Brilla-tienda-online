# Brilla - Tienda online

Brilla es una tienda online de accesorios, bolsos y bijouterie.

## Cómo abrirla
1. Descargá y descomprimí la carpeta.
2. Abrí el archivo `index.html` con un navegador.
3. Explorá los productos, usá el buscador y los filtros, y agregá artículos al carrito.

## Funcionalidades
- Catálogo con imagen ilustrativa, nombre y precio.
- Categorías y búsqueda.
- Carrito con modificación de cantidades y eliminación.
- Cálculo automático del total.
- Mensajes para las acciones.
- Lista de favoritos.
- Modo oscuro.
- Diseño adaptable a computadora y celular.

## Tecnologías
- HTML: estructura.
- CSS: diseño adaptable.
- JavaScript: búsqueda, filtros, favoritos y carrito.

## Publicación
Para publicar el proyecto, se puede subir esta carpeta a un repositorio de GitHub y activar GitHub Pages desde la configuración del repositorio.

## Uso de herramientas de IA
Se utilizaron herramientas de IA como apoyo para proponer ideas, organizar el diseño y revisar partes del código. El funcionamiento de la página debe ser revisado y comprendido antes de presentarlo.
